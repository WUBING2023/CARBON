# Revised Figure 3b illustrative display protocol

This is an explicitly **post hoc illustration rule**, not a validation-success rate or a new statistical analysis. The complete 485-query × 1,583-target Tomtom run, native p/q values, negative comparisons and overall counts are unchanged. The prior q-only display is archived in `display_before_information_filter_20261013`.

Eligibility retains exact same RBP Gene_name, Homo_sapiens, Mutated=no, forward positive `pos_pattern_0`, and reference width ≤10 nt. It additionally requires native per-query q<0.01 and **query** mean IC≥0.3 bits in both the matched and current display intervals. Target IC is recorded for audit, not used as an additional criterion.

For each normalized probability row, IC = 2 + Σ p log₂ p, using uniform A/C/G/U background. No small-sample correction or logo-height amplification is applied. The matched interval is the actual stored forward Tomtom overlap. The unchanged display viewport has width `max(9, target_width+2)` and centre `−Optimal_offset+(target_width−1)/2`. Display mean IC weights each nucleotide cell by its visible intersection length, then divides by the **entire viewport width**; outside-query blank padding contributes zero. This differs from averaging only visible query columns.

1. Within each RBP, sort eligible pairs by q, p, task and Target_ID ascending; Target_ID ties use string order. Retain the first pair.
2. Sort these distinct-RBP representatives by q, p, RBP, task and Target_ID ascending. Display the first five in that order.
3. From the remaining representatives, select the greatest query display mean IC. Resolve ties by q, p, RBP, task and Target_ID ascending. Display this row sixth.

The 770 base-eligible pairs contain 46 pairs with q<0.01. Both query IC thresholds retain 33 pairs across nine distinct RBPs. The final rows are:

| Order / stage | RBP / cell | Query / target | Native q | Query matched / display mean IC (bits) |
|---|---|---|---:|---:|
| 1 / five lowest q | PTBP1 / HepG2 | PTBP1_HepG2_ENCSR384KAN__pos_pattern_0 / s100 | 1.49271e-06 | 0.722588 / 0.703105 |
| 2 / five lowest q | PCBP2 / HepG2 | PCBP2_HepG2_ENCSR339FUY__pos_pattern_0 / 791 | 0.000170423 | 0.699533 / 0.684192 |
| 3 / five lowest q | RBM5 / HepG2 | RBM5_HepG2_ENCSR489ABS__pos_pattern_0 / 1150 | 0.000225272 | 0.856935 / 0.873779 |
| 4 / five lowest q | HNRNPK / HepG2 | HNRNPK_HepG2_ENCSR828ZID__pos_pattern_0 / 1026 | 0.000234269 | 0.648095 / 0.755590 |
| 5 / five lowest q | U2AF2 / HepG2 | U2AF2_HepG2_ENCSR202BFN__pos_pattern_0 / M077_0.6 | 0.00118624 | 0.429422 / 0.407968 |
| 6 / greatest remaining display IC | PUM2 / K562 | PUM2_K562_ENCSR661ICQ__pos_pattern_0 / 116 | 0.00459785 | 1.412544 / 1.130035 |

The prior PCBP1 query/target 763 has unchanged q=0.000103707 and matched/display mean IC=0.069330/0.063112 bits. It is retained with both low-IC exclusion reasons. All alternative hits, unchosen best-per-RBP representatives and non-significant pairs remain in the complete candidate table. PUM2's 8-nt query is displayed in a 10-nt viewport (−1.5 to 8.5), so blank padding lowers its display mean to 1.130035 bits. This new ATtRACT q is separate from the historical CISBP PUM2 result in panel c.

Native q is preserved from each query's search against all 1,583 targets; it is not a new FDR estimate over the filtered display. Several selected references are homopolymers. High IC does not imply sequence complexity, fine-grained specificity or functional validation. PUM2 target116's official metadata reports RIP-chip, database code C and PMID18776931; references remain heterogeneous rather than uniformly direct experimental gold standards.

Machine-readable audit: `attract_run/ATtRACT_DISPLAY_SELECTION_V3.json`, `ATtRACT_display_candidate_audit_all_1626.csv`, `ATtRACT_same_RBP_all_patterns.csv`, `ATtRACT_best_pattern0_per_RBP.csv` and `ATtRACT_main_best_q_six.csv`. These record full-precision IC, interval/blank coverage, exclusions, best-per-RBP status, selection stages, display order and original p/q. The full statistical outputs are unchanged.
