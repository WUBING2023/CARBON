"""Audit exact complete Tomtom output and freeze explicit best-q display rows."""
from pathlib import Path
import csv,json,hashlib,gzip,collections
import pandas as pd

W=Path(__file__).resolve().parent;OUT=W/'attract_run'
def main():
    run=json.loads((OUT/'TOMTOM_RUN_PROVENANCE.json').read_text());assert run['state']=='complete'
    queries={r['Query_ID']:r for r in csv.DictReader((OUT/'query_universe.csv').open())}
    targets={r['Target_ID']:r for r in csv.DictReader((OUT/'target_universe.csv').open())}
    metadata=list(csv.DictReader((OUT/'ATtRACT_metadata_all_4882.csv').open()))
    human=collections.defaultdict(list)
    for r in metadata:
        if r['Organism']=='Homo_sapiens' and r['Mutated'].lower()=='no':human[(r['Gene_name'],r['Matrix_id'])].append(r)
    seen={q:set() for q in queries};any_sig=collections.Counter();same=[];all_sig=0;total=0
    raw=OUT/'tomtom_all_767755_pairs.tsv'
    with raw.open('w',newline='') as output:
        writer=None
        for path in sorted(OUT.glob('tomtom_batch_*.tsv')):
            records=csv.DictReader((line for line in path.open() if line.strip() and not line.startswith('#')),delimiter='\t')
            if writer is None:writer=csv.DictWriter(output,records.fieldnames,delimiter='\t');writer.writeheader()
            for r in records:
                q=r['Query_ID'];t=r['Target_ID'];assert q in queries and t in targets
                assert t not in seen[q],(q,t);seen[q].add(t);assert r['Orientation']=='+'
                writer.writerow(r);total+=1
                significant=float(r['q-value'])<.05
                if significant:all_sig+=1;any_sig[q]+=1
                query=queries[q];refs=human.get((query['RBP'],t),[])
                if refs:
                    same.append(dict(**r,task=query['task'],RBP=query['RBP'],cell=query['cell'],pattern=query['pattern'],query_width=query['width'],
                                     target_width=targets[t]['width'],metadata_record_count=len(refs),
                                     ATtRACT_databases=';'.join(sorted({x['Database'] for x in refs})),
                                     ATtRACT_assays=';'.join(sorted({x['Experiment_description'] for x in refs})),
                                     ATtRACT_pubmed=';'.join(sorted({x['Pubmed'] for x in refs})),
                                     ATtRACT_reference_sequences=';'.join(sorted({x['Motif'] for x in refs})),
                                     organism='Homo_sapiens',mutated='no',
                                     direct_inferred_status='Not exposed in ATtRACT bulk schema',
                                     main_eligible=query['pattern']=='pos_pattern_0' and int(targets[t]['width'])<=10))
    assert total==len(queries)*len(targets)==767755,total
    assert all(len(s)==len(targets) for s in seen.values())
    d=pd.DataFrame(same);d['main_selected']=False;d['main_order']=0
    eligible=d[d.main_eligible].copy()
    eligible['sort_q']=eligible['q-value'].astype(float);eligible['sort_p']=eligible['p-value'].astype(float)
    best=eligible.sort_values(['sort_q','sort_p','task','Target_ID']).drop_duplicates('RBP')
    selected=best.sort_values(['sort_q','sort_p','RBP','task','Target_ID']).head(6)
    assert len(selected)==6
    for i,index in enumerate(selected.index):d.loc[index,['main_selected','main_order']]=[True,i+1]
    selected=d[d.main_selected].sort_values('main_order')
    d.to_csv(OUT/'ATtRACT_same_RBP_all_patterns.csv',index=False)
    best.drop(columns=['sort_q','sort_p']).to_csv(OUT/'ATtRACT_best_pattern0_per_RBP.csv',index=False)
    selected.to_csv(OUT/'ATtRACT_main_best_q_six.csv',index=False)
    coverage=[]
    for q,query in queries.items():
        sd=d[d.Query_ID==q];p0=query['pattern']=='pos_pattern_0'
        coverage.append(dict(**query,all_target_comparisons=len(seen[q]),all_target_q_lt_005=any_sig[q],
                             same_RBP_human_unmutated_comparisons=len(sd),same_RBP_q_lt_005=int((sd['q-value'].astype(float)<.05).sum()),
                             display_eligible_comparisons=int(sd.main_eligible.sum()),
                             status='No same-RBP human unmutated ATtRACT reference' if sd.empty else 'Same-RBP references present; no significant match' if not (sd['q-value'].astype(float)<.05).any() else 'Same-RBP significant match'))
    pd.DataFrame(coverage).to_csv(OUT/'ATtRACT_query_coverage_all_485.csv',index=False)
    p0=d[d.pattern=='pos_pattern_0'];positive=d[d['q-value'].astype(float)<.05];p0positive=p0[p0['q-value'].astype(float)<.05]
    summary=dict(all_query_tasks=219,all_query_patterns=len(queries),all_target_unique_matrices=len(targets),all_pair_comparisons=total,
                 all_target_significant_pair_count=all_sig,
                 all_target_significant_count_meaning='Includes other RBPs/species; not a same-RBP validation rate.',
                 same_RBP_human_unmutated_pair_count=len(d),same_RBP_significant_pairs=len(positive),same_RBP_significant_task_patterns=positive.Query_ID.nunique(),
                 same_RBP_significant_tasks=positive.task.nunique(),same_RBP_significant_RBPs=positive.RBP.nunique(),
                 pattern0_same_RBP_pairs=len(p0),pattern0_significant_pairs=len(p0positive),pattern0_significant_tasks=p0positive.task.nunique(),pattern0_significant_RBPs=p0positive.RBP.nunique(),
                 main_reference_width_le_10_eligible_RBPs=len(best),main_selection='Initial q-only representatives; finalized display selection is applied by select_attract_information_v3.py after the complete audit.',
                 main_rows=selected.to_dict('records'),all_485_by_1583_pairs_verified=True,reverse_complement_matches=0,
                 q_family='Native Tomtom q for each query against all 1583 unique reference matrices; not global correction across queries.',
                 original_CISBP_results='Preserved separately; no original p/q recalculation or relabelling.',
                 raw_tsv_sha256=hashlib.sha256(raw.read_bytes()).hexdigest())
    (OUT/'ATtRACT_RESULT_AUDIT.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    with raw.open('rb') as source,gzip.open(OUT/'tomtom_all_767755_pairs.tsv.gz','wb') as dest:
        for block in iter(lambda:source.read(1024*1024),b''):dest.write(block)
    from select_attract_information_v3 import main as finalize_display
    finalize_display()
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
