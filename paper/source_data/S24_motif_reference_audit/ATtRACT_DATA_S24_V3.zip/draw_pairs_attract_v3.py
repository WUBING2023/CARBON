"""Native vector table for the audited post hoc q/information-content examples."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import draw_fig3 as d

W=Path(__file__).resolve().parent
d.BASES={'A':'#6BB72D','C':'#19499C','G':'#F4A016','U':'#E6211A'}

def main():
    run=W/'attract_run'
    rows=pd.read_csv(run/'ATtRACT_main_best_q_six.csv',dtype={'Query_ID':str,'Target_ID':str})
    queries=np.load(run/'all_query_ppms.npz');targets=np.load(run/'all_target_ppms.npz')
    fig=plt.figure(figsize=(85/25.4,49/25.4),facecolor='white')
    d.mm_text(fig,.4,.5,'b',fontsize=9,fontweight='bold')
    for x,text in [(31.5,'CARBON'),(57,'ATtRACT'),(77,'q-value')]:
        d.mm_text(fig,x,1.2,text,fontsize=6,ha='center')
    geometries=[]
    for j,row in enumerate(rows.to_dict('records')):
        y=7.0+j*6.8;q=queries[row['Query_ID']];r=targets[row['Target_ID']]
        assert row['Orientation']=='+'
        rs=-int(row['Optimal_offset']);n=max(9,len(r)+2);mid=rs+(len(r)-1)/2
        extent=(mid-n/2,mid+n/2)
        d.mm_text(fig,1.5,y,row['RBP'],fontsize=6.5)
        d.mm_text(fig,1.5,y+2.7,row['cell'],fontsize=5.5)
        d.logo(d.mm_axes(fig,19.0,y,25.0,4.6),q,extent=extent)
        d.logo(d.mm_axes(fig,44.5,y,25.0,4.6),r,start=rs,extent=extent)
        d.mm_text(fig,77,y+1.3,f"{float(row['q-value']):.2e}" if float(row['q-value'])<.001 else f"{float(row['q-value']):.3g}",fontsize=6.5,ha='center')
        geometries.append(dict(order=j+1,task=row['task'],Query_ID=row['Query_ID'],Target_ID=row['Target_ID'],
          orientation='+',optimal_offset=row['Optimal_offset'],reference_start_in_query_coordinates=rs,
          query_width=len(q),reference_width=len(r),display_extent_query_coordinates=list(extent),
          equal_nucleotide_spacing_mm=25.0/n,p_value=str(row['p-value']),q_value=str(row['q-value']),
          selection_stage=row['selection_stage'],
          query_matched_mean_IC_bits=float(row['query_matched_mean_IC_bits']),
          query_display_mean_IC_bits_including_blank_padding=float(row['query_display_mean_IC_bits_including_blank_padding']),
          target_matched_mean_IC_bits=float(row['target_matched_mean_IC_bits']),
          target_display_mean_IC_bits_including_blank_padding=float(row['target_display_mean_IC_bits_including_blank_padding']),
          common_yaxis_bits=[0,2.08],maximum_information_bits=2,
          full_original_matrices='attract_run/all_query_ppms.npz; attract_run/all_target_ppms.npz',
          display_crop_note='Same positive pattern 0 as atlas leaf; alignment-centred display crop may differ from atlas frozen 9-nt crop.'))
    d.mm_text(fig,42.5,46.8,'Logo height: information content (0–2 bits)',fontsize=5.5,ha='center')
    fig.savefig(W/'fig3b_attract_v3.pdf');fig.savefig(W/'fig3b_attract_v3.svg');fig.savefig(W/'fig3b_attract_v3.png',dpi=600)
    plt.close(fig)
    (W/'FIG3_B_ALIGNMENT_V3.json').write_text(json.dumps(geometries,indent=2),encoding='utf-8')
    print(json.dumps(geometries,indent=2))

if __name__=='__main__':main()
