"""Build a bounded Data S24 addon; exclude abandoned build trees and duplicate TSVs."""
from pathlib import Path
import zipfile,json,hashlib,csv
W=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    mandatory=['ATtRACT_official_20261012.zip','ATtRACT_PRISMNET_SOURCE_NOTES.md','ATtRACT_VERIFIED_CITATION.bib',
      'ATtRACT_CONVERSION_AND_RANDOMNESS.md','V3_INSERTIONS.md','FIG3_B_ALIGNMENT_V3.json',
      'prepare_attract_v3.py','run_attract_tomtom_v3.py','audit_attract_results_v3.py',
      'draw_pairs_attract_v3.py','select_attract_information_v3.py','package_attract_v3.py',
      'DISPLAY_SELECTION_PROTOCOL_20261013.md','fig3b_attract_v3.pdf','fig3b_attract_v3.svg',
      'tools/meme_bioconda/bin/tomtom']
    selected=[W/x for x in mandatory]
    selected.extend((W/'attract_official').glob('*'))
    run=W/'attract_run'
    selected.extend(p for p in run.iterdir() if p.is_file() and p.suffix in ['.csv','.json','.meme','.npz'])
    selected.extend(run.glob('*.stderr.txt'))
    selected.append(run/'tomtom_all_767755_pairs.tsv.gz')
    selected.extend((run/'query_sources').rglob('queries.meme'))
    selected=sorted(set(selected));assert all(p.is_file() for p in selected)
    manifest=[dict(path=p.relative_to(W).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in selected]
    (W/'ATtRACT_DATA_S24_V3_MANIFEST.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    summary=json.loads((run/'ATtRACT_RESULT_AUDIT.json').read_text())
    readme=f'''ATtRACT addon for Data S24, CARBON revision v3

This is a separate new analysis, not a replacement or relabelling of the original 193-row CISBP result.
All 485 query motifs from 219 tasks were searched against the official 1,583-ID target universe with native Tomtom 5.5.7, -norc, Pearson, minimum overlap 4. All 767,755 rows are retained in attract_run/tomtom_all_767755_pairs.tsv.gz (standard gzip TSV). q-values are native per-query full-target-family values, not global across queries.

attract_run/ATtRACT_same_RBP_all_patterns.csv contains all 1,626 exact same-RBP human unmutated query-target pairs, including the 1,392 non-significant pairs. Metadata from multiple records for the same Matrix_id is joined without duplicating statistical comparisons. main_selected/main_order identify the six displayed post hoc examples. The 4,882 uncollapsed metadata records and original bulk source are also supplied.
attract_run/ATtRACT_query_coverage_all_485.csv retains all queries, including queries without any eligible same-RBP reference. ATtRACT_RESULT_AUDIT.json records coverage counts and frozen selection rules; no missing references are counted as positive evidence.

The complete exact converted query/target MEME files, four frozen batch files, original query MEME files, matrices, native stderr progress logs, input hashes, binary hash, command lines and exit codes are preserved. Target nsites=20 is a stated conversion default because the official PWM file gives no site count; query nsites=20 is preserved from original exports. All probability rows were normalized only for decimal-rounding differences. Read ATtRACT_CONVERSION_AND_RANDOMNESS.md for the pseudocount/background and frozen bootstrap/batch reproducibility details.

To reproduce in Linux/WSL, place this package at the work_fig3 directory, chmod +x tools/meme_bioconda/bin/tomtom and run python3 run_attract_tomtom_v3.py. The native binary needs only libc/libm. Input preparation/audit needs numpy/pandas. The original source-build tree is intentionally excluded: this package preserves the exact verified binary that completed the recorded run. Do not rerun into the archived output directory unless intentionally reproducing in a separate copy.

Source version: official ATtRACT archive acquired 12 October 2026; the download/archive gives no build number. The bulk schema does not expose CISBP direct/inferred status. Do not call all database entries direct experimental gold standards. The source/citation files identify primary official URLs and the verified Giudice et al. 2016 citation.

Post hoc display selection: retain exact-same-RBP human unmutated positive pattern 0 references <=10 nt, q<0.01 and query matched/display mean IC both >=0.3 bits. For each RBP choose best q,p,task,Target_ID (ascending); sort representatives by q,p,RBP,task,Target_ID and take five. The sixth is the remaining representative with highest query display mean IC (ties q,p,RBP,task,Target_ID). The display mean weights nucleotide-cell overlap with the unchanged reference-centred viewport and divides by the entire viewport width; blank outside-query padding contributes zero. Target IC is recorded, not an additional filter. The 770 base-eligible pairs yield 46 q<0.01 pairs, 33 information-eligible pairs and nine distinct RBP representatives. The two-stage display includes PTBP1, PCBP2, RBM5, HNRNPK, U2AF2 and PUM2. PCBP1 remains in the complete comparisons/candidate audit with both low-IC exclusion reasons. No run/statistical cohort or native p/q changes. See ATtRACT_DISPLAY_SELECTION_V3.json and ATtRACT_display_candidate_audit_all_1626.csv.

Scientific display limitation: this information-content filter and two-stage choice are explicitly post hoc for illustration, not a validation-success rate. Several selected references are homopolymers; high IC does not establish sequence complexity or fine-grained RBP specificity. A small Pearson-based q alone does not establish high IC. Logos retain the common 0–2-bit information scale without amplifying weak logos. All 485-query x 1,583-target results and all non-displayed candidates are retained.
'''
    (W/'ATtRACT_DATA_S24_V3_README.txt').write_text(readme,encoding='utf-8')
    destination=W/'ATtRACT_DATA_S24_V3.zip'
    with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in selected:z.write(p,p.relative_to(W).as_posix())
        for name in ['ATtRACT_DATA_S24_V3_MANIFEST.json','ATtRACT_DATA_S24_V3_README.txt']:z.write(W/name,name)
    with zipfile.ZipFile(destination) as z:assert z.testzip() is None
    print(json.dumps(dict(package=destination.name,files=len(selected)+2,bytes=destination.stat().st_size,sha256=sha(destination))))
if __name__=='__main__':main()
