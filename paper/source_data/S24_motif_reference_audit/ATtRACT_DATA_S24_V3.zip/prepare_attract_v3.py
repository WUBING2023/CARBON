"""Preserve the complete official ATtRACT and frozen 219-task query universes."""
from pathlib import Path
import json, hashlib, re, shutil
import numpy as np
import pandas as pd

W=Path(__file__).resolve().parent
ORIGINAL=Path('M:/RBP/26年数据RBP/可解释性分析/Motif/outputs')
OUT=W/'attract_run'; OUT.mkdir(exist_ok=True)

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read_meme(path):
    lines=path.read_text(encoding='utf-8').splitlines(); out={}
    for i,line in enumerate(lines):
        if line.startswith('MOTIF '):
            key=line.split()[1]; k=i+1
            while not lines[k].startswith('letter-probability matrix:'):k+=1
            width=int(re.search(r'w=\s*(\d+)',lines[k]).group(1))
            out[key]=np.array([[float(v) for v in row.split()] for row in lines[k+1:k+1+width]])
    return out
def write_meme(path,arrays):
    with path.open('w',encoding='utf-8',newline='\n') as f:
        f.write('MEME version 4\nALPHABET= ACGU\nstrands: +\nBackground letter frequencies:\nA 0.25 C 0.25 G 0.25 U 0.25\n\n')
        for key,raw in arrays.items():
            p=raw/raw.sum(axis=1,keepdims=True)
            f.write(f'MOTIF {key}\nletter-probability matrix: alength= 4 w= {len(p)} nsites= 20 E= 0\n')
            for row in p:f.write(' '.join(f'{v:.12g}' for v in row)+'\n')
            f.write('\n')

def main():
    meta=pd.read_csv(W/'source_inputs/Supplementary_Data_S10_motif_leaf_mapping.csv')
    qrows=[];queries={}
    for row in meta.itertuples():
        source=ORIGINAL/row.task_id/'tfmodisco_export/queries.meme'
        copy=OUT/'query_sources'/row.task_id/'queries.meme';copy.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,copy)
        for pattern,ppm in read_meme(copy).items():
            key=row.task_id+'__'+pattern;queries[key]=ppm
            qrows.append(dict(Query_ID=key,task=row.task_id,RBP=row.task_id.split('_')[0],cell=row.task_id.split('_')[1],pattern=pattern,
                              in_atlas=pattern=='pos_pattern_0',width=len(ppm),source_sha256=sha(copy),original_query=str(source)))
    lines=(W/'attract_official/pwm.txt').read_text().splitlines();targets={}
    for i,line in enumerate(lines):
        if line.startswith('>'):
            key,width=line[1:].split();width=int(width)
            targets[key]=np.array([[float(v) for v in row.split()] for row in lines[i+1:i+1+width]])
    records=pd.read_csv(W/'attract_official/ATtRACT_db.txt',sep='\t',dtype=str)
    assert set(records.Matrix_id)==set(targets)
    write_meme(OUT/'queries_all_219_tasks_485_patterns.meme',queries)
    write_meme(OUT/'targets_all_official_1583.meme',targets)
    pd.DataFrame(qrows).to_csv(OUT/'query_universe.csv',index=False)
    pd.DataFrame([dict(Target_ID=k,width=len(v),metadata_records=int((records.Matrix_id==k).sum())) for k,v in targets.items()]).to_csv(OUT/'target_universe.csv',index=False)
    records.to_csv(OUT/'ATtRACT_metadata_all_4882.csv',index=False)
    np.savez_compressed(OUT/'all_query_ppms.npz',**queries);np.savez_compressed(OUT/'all_target_ppms.npz',**targets)
    note=dict(acquired_utc_date='2026-10-12',official_database_url='https://attract.cnic.es/download',
              official_zip_url='https://attract.cnic.es/attract/static/ATtRACT.zip',database_version='Official bulk snapshot; release/build version not declared by download page or archive README',
              tasks=len(meta),query_motifs=len(queries),unique_target_pwms=len(targets),metadata_records=len(records),
              expected_all_pair_rows=len(queries)*len(targets),query_width_min=min(map(len,queries.values())),query_width_max=max(map(len,queries.values())),
              matrix_conversion='A/C/G/U column order retained; rows normalized only for decimal-rounding differences; no trimming or information-content rescaling.',
              background='Uniform RNA nucleotide frequencies A=C=G=U=0.25',
              statistical_family='Tomtom computes q-values for each query against all 1583 targets, not a global FDR over 485*1583 pairs.',
              frozen_posthoc_display_rule='Retain same exact human RBP Gene_name, Mutated=no, positive pattern 0 present in atlas, reference width<=10 nt. Rank eligible hits by q-value, p-value, task and Target_ID; take one best hit per RBP and display the six distinct RBP best hits with smallest q. Full all-target results, negatives and task availability stay available. This is post hoc favorable-example selection, not a validation-rate estimate.',
              target_provenance_limit='ATtRACT includes multiple source databases and assay labels; the bulk schema does not expose CISBP direct/inferred flags. Call these ATtRACT references and retain the original source/assay metadata; do not label all as directly measured gold standards.',
              source_sha256={p.name:sha(p) for p in [W/'ATtRACT_official_20261012.zip',W/'attract_official/ATtRACT_db.txt',W/'attract_official/pwm.txt',W/'source_inputs/Supplementary_Data_S10_motif_leaf_mapping.csv',OUT/'queries_all_219_tasks_485_patterns.meme',OUT/'targets_all_official_1583.meme']})
    (OUT/'ATtRACT_RUN_INPUTS.json').write_text(json.dumps(note,indent=2),encoding='utf-8');print(json.dumps(note,indent=2))

if __name__=='__main__':main()
