"""Run exact Tomtom independently over complete 1583-target families in WSL."""
from pathlib import Path
import re,json,hashlib,subprocess,time
from concurrent.futures import ThreadPoolExecutor
W=Path(__file__).resolve().parent;OUT=W/'attract_run'
EXE=W/'tools/meme_bioconda/bin/tomtom'

def main():
    source=(OUT/'queries_all_219_tasks_485_patterns.meme').read_text()
    parts=re.split(r'(?m)^MOTIF ',source);header=parts[0]
    records=[('MOTIF '+p,int(re.search(r'w=\s*(\d+)',p).group(1))) for p in parts[1:]]
    blocks=[[] for _ in range(4)];loads=[0]*4
    for index,(text,width) in sorted(enumerate(records),key=lambda z:-z[1][1]**3):
        k=min(range(4),key=lambda j:loads[j]);blocks[k].append((index,text));loads[k]+=width**3
    commands=[]
    for k,block in enumerate(blocks):
        qfile=OUT/f'queries_batch_{k+1}.meme';qfile.write_text(header+''.join(text for index,text in sorted(block)))
        cmd=[str(EXE),'-text','-norc','-no-ssc','-dist','pearson','-min-overlap','4','-evalue','-thresh','1000000',str(qfile),str(OUT/'targets_all_official_1583.meme')]
        commands.append(cmd)
    version=subprocess.check_output([str(EXE),'-version'],text=True).strip()
    note=dict(tomtom_version=version,binary_sha256=hashlib.sha256(EXE.read_bytes()).hexdigest(),
              distribution='Bioconda meme 5.5.7 pl5321h1ca524f_3; exact native Tomtom, no approximation or alternate q computation',
              source_package_url='https://api.anaconda.org/download/bioconda/meme/5.5.7/linux-64/meme-5.5.7-pl5321h1ca524f_3.tar.bz2',
              commands=commands,batch_query_counts=[len(x) for x in blocks],
              significance_output_threshold='E-value 1000000 exceeds the maximum possible E-value 1583, preserving all target pairs.',
              q_family='Each query versus every one of the 1583 unique official target PWMs; independent query batching does not truncate a target family. Not a global q over 767755 pairs.',
              defaults='Uniform input A/C/G/U background. Default motif pseudocount 0.1 distributed by background, default complete scores; Pearson distance; min overlap 4; no reverse-complement scoring; default Tomtom pi-zero bootstrap estimate.',
              source_build_failure='Two source-build attempts ended abruptly when WSL stopped without a compiler error; the verified same-version Bioconda binary requires only system libc/libm and reports 5.5.7.',
              start_epoch=time.time(),state='running')
    (OUT/'TOMTOM_RUN_PROVENANCE.json').write_text(json.dumps(note,indent=2))
    def run(pair):
        k,cmd=pair;start=time.time()
        with (OUT/f'tomtom_batch_{k+1}.tsv').open('w') as o,(OUT/f'tomtom_batch_{k+1}.stderr.txt').open('w') as e:
            p=subprocess.run(cmd,stdout=o,stderr=e)
        return dict(batch=k+1,returncode=p.returncode,seconds=time.time()-start)
    with ThreadPoolExecutor(max_workers=4) as pool:
        results=list(pool.map(run,enumerate(commands)))
    note.update(state='complete' if all(x['returncode']==0 for x in results) else 'failed',results=results,end_epoch=time.time())
    (OUT/'TOMTOM_RUN_PROVENANCE.json').write_text(json.dumps(note,indent=2));print(json.dumps(note,indent=2))
    assert note['state']=='complete'

if __name__=='__main__':main()
