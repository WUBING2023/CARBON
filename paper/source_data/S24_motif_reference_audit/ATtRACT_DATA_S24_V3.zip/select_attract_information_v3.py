"""Post hoc display-only selection; retain native full-family Tomtom statistics."""
from pathlib import Path
import csv, json, hashlib
import numpy as np

W = Path(__file__).resolve().parent
OUT = W / 'attract_run'
BACKUP = W / 'display_before_information_filter_20261013'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def column_ic(ppm):
    p = np.asarray(ppm, dtype=float)
    p = p / p.sum(axis=1, keepdims=True)
    return np.maximum(0, 2 + np.sum(p * np.log2(np.maximum(p, 1e-300)), axis=1))

def visible_mean(ic, start, left, right):
    centers = start + np.arange(len(ic), dtype=float)
    weights = np.maximum(0, np.minimum(centers + .5, right) - np.maximum(centers - .5, left))
    return float(np.dot(weights, ic) / (right-left)), float(weights.sum())

def geometry(row, queries, targets):
    q = queries[row['Query_ID']]; t = targets[row['Target_ID']]
    qi = column_ic(q); ti = column_ic(t)
    rs = -int(row['Optimal_offset'])
    left_overlap = max(0, rs); right_overlap = min(len(q), rs+len(t))
    assert right_overlap-left_overlap == int(row['Overlap'])
    width = max(9, len(t)+2); mid = rs+(len(t)-1)/2
    left = mid-width/2; right = mid+width/2
    display_q, coverage_q = visible_mean(qi, 0, left, right)
    display_t, coverage_t = visible_mean(ti, rs, left, right)
    return {
        'query_matched_mean_IC_bits': float(qi[left_overlap:right_overlap].mean()),
        'query_display_mean_IC_bits_including_blank_padding': display_q,
        'target_matched_mean_IC_bits': float(ti[left_overlap-rs:right_overlap-rs].mean()),
        'target_display_mean_IC_bits_including_blank_padding': display_t,
        'matched_query_start_0based': left_overlap,
        'matched_query_end_exclusive': right_overlap,
        'display_left_query_coordinates': left,
        'display_right_query_coordinates': right,
        'display_width_nt': width,
        'query_coverage_within_display_nt': coverage_q,
        'target_coverage_within_display_nt': coverage_t,
    }

def hit_key(row):
    return float(row['q-value']), float(row['p-value']), row['task'], row['Target_ID']

def representative_key(row):
    return float(row['q-value']), float(row['p-value']), row['RBP'], row['task'], row['Target_ID']

def write_csv(path, rows):
    with path.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)

def main():
    immutable = ['tomtom_all_767755_pairs.tsv.gz', 'query_universe.csv', 'target_universe.csv',
                 'all_query_ppms.npz', 'all_target_ppms.npz', 'ATtRACT_query_coverage_all_485.csv', 'TOMTOM_RUN_PROVENANCE.json']
    hashes = {n: sha(OUT/n) for n in immutable}
    # Start from the archived original strings so native p/q and metadata are
    # retained verbatim rather than subjected to pandas float serialization.
    source = BACKUP/'attract_run/ATtRACT_same_RBP_all_patterns.csv'
    if not source.exists(): source = OUT/'ATtRACT_same_RBP_all_patterns.csv'
    rows = list(csv.DictReader(source.open(encoding='utf-8')))
    # A fresh full-run audit writes this original schema; archived display
    # metrics are removed on a repeat display-selection pass.
    schema = list(rows[0]); schema = schema[:schema.index('main_order')+1]
    rows = [{k:r[k] for k in schema} for r in rows]
    original_columns = list(rows[0])
    queries = np.load(OUT/'all_query_ppms.npz'); targets = np.load(OUT/'all_target_ppms.npz')
    for row in rows:
        assert row['organism'] == 'Homo_sapiens' and row['mutated'] == 'no' and row['Orientation'] == '+'
        row.update(geometry(row, queries, targets))
        base = row['pattern'] == 'pos_pattern_0' and int(row['target_width']) <= 10
        reasons = []
        if row['pattern'] != 'pos_pattern_0': reasons.append('not_positive_pattern0')
        if int(row['target_width']) > 10: reasons.append('reference_width_gt_10')
        if float(row['q-value']) >= .01: reasons.append('q_not_lt_0.01')
        if row['query_matched_mean_IC_bits'] < .3: reasons.append('query_matched_mean_IC_lt_0.3_bits')
        if row['query_display_mean_IC_bits_including_blank_padding'] < .3: reasons.append('query_display_mean_IC_lt_0.3_bits')
        row['main_eligible'] = base
        row['display_q_lt_001'] = float(row['q-value']) < .01
        row['display_query_matched_IC_ge_03'] = row['query_matched_mean_IC_bits'] >= .3
        row['display_query_display_IC_ge_03'] = row['query_display_mean_IC_bits_including_blank_padding'] >= .3
        row['display_information_eligible'] = not reasons
        row['display_exclusion_reasons'] = ';'.join(reasons)
        row['best_eligible_hit_for_RBP'] = False
        row['main_selected'] = False; row['main_order'] = 0; row['selection_stage'] = ''
    eligible = [r for r in rows if r['display_information_eligible']]
    best_by_rbp = {}
    for row in sorted(eligible, key=hit_key):
        best_by_rbp.setdefault(row['RBP'], row)
    best = sorted(best_by_rbp.values(), key=representative_key)
    assert len(best) >= 6
    selected = best[:5]
    remaining = best[5:]
    sixth = sorted(remaining, key=lambda r: (-r['query_display_mean_IC_bits_including_blank_padding'],)+representative_key(r))[0]
    selected.append(sixth)
    for row in best: row['best_eligible_hit_for_RBP'] = True
    for order, row in enumerate(selected, 1):
        row['main_selected'] = True; row['main_order'] = order
        row['selection_stage'] = 'five_lowest_q_representatives' if order <= 5 else 'highest_display_IC_remaining_representative'
    for row in eligible:
        if not row['best_eligible_hit_for_RBP']:
            row['display_exclusion_reasons'] = 'not_best_q_hit_for_RBP'
        elif not row['main_selected']:
            row['display_exclusion_reasons'] = 'not_chosen_by_two_stage_display_rule'
    assert [r['RBP'] for r in selected] == ['PTBP1','PCBP2','RBM5','HNRNPK','U2AF2','PUM2']
    assert len(eligible) == 33 and len(best) == 9
    # Existing result columns, excluding only display flags, remain verbatim.
    originals = list(csv.DictReader(source.open(encoding='utf-8')))
    for old, new in zip(originals, rows):
        for key in original_columns:
            if key not in ['main_eligible','main_selected','main_order']:
                assert old[key] == new[key], key
    write_csv(OUT/'ATtRACT_same_RBP_all_patterns.csv', rows)
    write_csv(OUT/'ATtRACT_display_candidate_audit_all_1626.csv', rows)
    write_csv(OUT/'ATtRACT_best_pattern0_per_RBP.csv', best)
    write_csv(OUT/'ATtRACT_main_best_q_six.csv', selected)
    protocol = {
        'classification': 'Post hoc illustrative display selection, not a validation-success rate',
        'base_eligibility': ['exact same RBP Gene_name','Homo_sapiens','Mutated=no','positive pos_pattern_0','reference width <=10 nt'],
        'additional_display_eligibility': ['native per-query Tomtom q <0.01','query matched mean IC >=0.3 bits','query current-display mean IC >=0.3 bits'],
        'IC_definition': 'IC_i=2+sum_b p_ib log2(p_ib), uniform A/C/G/U background; probability rows normalized only; no small-sample correction or height amplification.',
        'matched_interval': 'Integer query columns shared with the forward reference placed at -Optimal_offset; interval length equals stored Overlap.',
        'display_interval': 'Unchanged reference-centred viewport: width=max(9, target_width+2), centre=-Optimal_offset+(target_width-1)/2.',
        'display_mean': 'Column information weighted by nucleotide-cell intersection with the viewport and divided by the entire viewport width; outside-query blank padding has zero IC.',
        'target_IC': 'Recorded for audit but not an additional selection criterion.',
        'within_RBP_best_hit_sort': ['q ascending','p ascending','task ascending','Target_ID ascending (string)'],
        'stage_1': 'Sort best-per-RBP representatives by q,p,RBP,task,Target_ID ascending; choose first five.',
        'stage_2': 'From remaining best-per-RBP representatives choose highest query display mean IC; ties by q,p,RBP,task,Target_ID ascending.',
        'display_order': 'Five stage-1 rows in q order followed by the stage-2 row.',
        'counts': {'same_RBP_human_unmutated_pairs':len(rows), 'base_eligible_pairs':sum(r['main_eligible'] for r in rows),
                   'base_eligible_q_lt_001_pairs':sum(r['main_eligible'] and r['display_q_lt_001'] for r in rows),
                   'information_eligible_pairs':len(eligible), 'information_eligible_distinct_RBPs':len(best), 'displayed_distinct_RBPs':len(selected)},
        'selected_rows': selected, 'all_best_per_RBP_rows': best,
        'excluded_previous_PCBP1_note': 'PCBP1 original best-q pair retained: query matched/display mean IC 0.069330/0.063112 bits fails both information thresholds; small native q remains unchanged.',
        'unaltered_full_run_inputs_outputs_sha256': hashes,
        'native_q_family': 'Each query against all 1583 targets; all 485 x 1583 results and coverage/statistics unchanged; no Tomtom rerun or external p/q recalculation.',
    }
    (OUT/'ATtRACT_DISPLAY_SELECTION_V3.json').write_text(json.dumps(protocol, indent=2), encoding='utf-8')
    original_audit = BACKUP/'attract_run/ATtRACT_RESULT_AUDIT.json'
    if not original_audit.exists(): original_audit = OUT/'ATtRACT_RESULT_AUDIT.json'
    audit = json.loads(original_audit.read_text(encoding='utf-8'))
    frozen = {k:v for k,v in audit.items() if k not in ['main_selection','main_rows']}
    audit['main_selection'] = protocol['stage_1']+' '+protocol['stage_2']+' Post hoc; q<0.01 and both query mean-IC thresholds >=0.3 bits.'
    audit['main_rows'] = selected
    audit['display_information_selection'] = protocol
    assert {k:audit[k] for k in frozen} == frozen
    (OUT/'ATtRACT_RESULT_AUDIT.json').write_text(json.dumps(audit, indent=2), encoding='utf-8')
    assert hashes == {n:sha(OUT/n) for n in immutable}
    print(json.dumps({'counts':protocol['counts'],'rows':[(r['RBP'],r['Target_ID'],r['q-value']) for r in selected]}, indent=2))

if __name__ == '__main__': main()
